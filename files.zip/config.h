#pragma once

// 0.91" SSD1306 OLED is typically 128x32
#define OLED_DISPLAY_128X32

// I2C is already set via keyboard.json i2c block, but if your QMK
// version needs it explicitly, uncomment these:
// #define I2C_DRIVER I2CD1
// #define I2C1_SDA_PIN GP6
// #define I2C1_SCL_PIN GP7
